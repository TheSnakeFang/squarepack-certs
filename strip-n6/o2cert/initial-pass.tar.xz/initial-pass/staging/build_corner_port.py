from pathlib import Path
root=Path('/Volumes/Kevin_SSD/GitHub/squarepack/o2cert')
base=root/'../runs/openmath-2026-10-27/handoff-routeA/pkg/proofs/m1-corner'
for folder in ('corner_original','corner_impl'):
 p=root/'src'/folder;p.mkdir(exist_ok=True)
 for n in ('iv.py','a7.py','run_corner.py'):(p/n).write_text((base/n).read_text())
p=root/'src/corner_impl/iv.py';s=p.read_text();s=s.replace('self.hi=float(lo if hi is None else hi)','self.hi=float(lo if hi is None else hi)\n        assert self.lo <= self.hi')
s=s.replace('lo,hi=1/math.sqrt(2),0.75','lo,hi=math.nextafter(math.sqrt(0.5),-math.inf),0.75').replace('r1,r2=1/math.sqrt(2),0.75','r1,r2=math.nextafter(math.sqrt(0.5),-math.inf),0.75')
# sqrt is correctly rounded on the target; retain extra padding for consistency.
s=s.replace('return I(math.nextafter(math.sqrt(a.lo),-math.inf),math.nextafter(math.sqrt(a.hi),math.inf))','return I(pad(math.sqrt(a.lo),False),pad(math.sqrt(a.hi),True))')
s=s.replace('return I(math.nextafter(math.acos(min(1.0,a.hi)),-math.inf),math.nextafter(math.acos(max(-1.0,a.lo)),math.inf))','return I(pad(math.acos(min(1.0,a.hi)),False),pad(math.acos(max(-1.0,a.lo)),True))')
s=s.replace('return I(math.nextafter(math.tan(a.lo),-math.inf),math.nextafter(math.tan(a.hi),math.inf))','return I(pad(math.tan(a.lo),False),pad(math.tan(a.hi),True))')
s+='''\n# Endpoints of subdivisions are shared binary64 numbers: interpolation need\n# not round outward internally, but the first and last must be exact parents.\ndef grid(a,k,n):\n    return a.lo if k==0 else a.hi if k==n else a.lo+(a.hi-a.lo)*k/n\ndef pad(x,positive):\n    for _ in range(8): x=math.nextafter(x, math.inf if positive else -math.inf)\n    return x\ndef down(x): return math.nextafter(x,-math.inf)\ndef up(x): return math.nextafter(x,math.inf)\n'''
p.write_text(s)
p=root/'src/corner_impl/a7.py';s=p.read_text();s=s.replace('D0 = 0.10','from iv import grid\nD0 = 0.10')
s=s.replace('hull.lo + (hull.hi - hull.lo) * k / 4, hull.lo + (hull.hi - hull.lo) * (k + 1) / 4','grid(hull,k,4), grid(hull,k+1,4)')
s=s.replace('C(min(M2, M2g) * dd / 4.0)','div(mul(I(min(M2,M2g)), I(dd)), I(4.0))')
p.write_text(s)
p=root/'src/corner_impl/run_corner.py';s=p.read_text();s=s.replace('from a7 import scan7, D0 as D0A7','from a7 import scan7, D0 as D0A7\nfrom iv import grid, down, up\nimport json\nfrom decimal import Decimal')
s=s.replace('xI.lo+(xI.hi-xI.lo)*k/nb, xI.lo+(xI.hi-xI.lo)*(k+1)/nb','grid(xI,k,nb), grid(xI,k+1,nb)')
s=s.replace('gm={}; tot=0; nopen=0','gm={}; tot=0; nopen=0; rows=[]')
s=s.replace('Hl=H0+(H1-H0)*hc/NH; Hh=H0+(H1-H0)*(hc+1)/NH; HI=I(Hl,Hh)','Hl=down(float(Decimal("1.87")+Decimal(".13")*hc/NH)); Hh=up(float(Decimal("1.87")+Decimal(".13")*(hc+1)/NH)); Hh=min(Hh,2.0); HI=I(Hl,Hh)')
s=s.replace('XI=I(Tlo-RC,Thi+RC); UI=I(1/Thi-RC,1/Tlo+RC)','XI=add(TI,I(-up(RC),up(RC))); UI=add(div(I(1.0),TI),I(-up(RC),up(RC)))')
s=s.replace('I(1.0/XI.hi,1.0/XI.lo)','div(I(1.0),XI)')
s=s.replace('Dmax=max(Lp,Lq)/XI.lo','Dmax=div(I(max(Lp,Lq)),I(XI.lo)).hi')
s=s.replace("M['A4']=g4-Dmax","M['A4']=sub(I(g4),I(Dmax)).lo")
s=s.replace("M['A5']=1.0+clo*(XI.lo+UI.lo)-muhi*(1.0-XI.lo*UI.lo)-Ax","end=add(I(1.0),mul(I(clo),add(I(XI.lo),I(UI.lo))))\n        M['A5']=sub(sub(end,mul(I(muhi),sub(I(1.0),mul(I(XI.lo),I(UI.lo))))),I(Ax)).lo")
s=s.replace("M['A6']=1.0+clo*(XI.lo+UI.lo)-Au","M['A6']=sub(end,I(Au)).lo")
s=s.replace('win=I(min(1.0/XI.hi,UI.lo), max(1.0/XI.lo,UI.hi))','inv=div(I(1.0),XI); win=I(min(inv.lo,UI.lo),max(inv.hi,UI.hi))')
s=s.replace('win.lo+(win.hi-win.lo)*k/60, win.lo+(win.hi-win.lo)*(k+1)/60','grid(win,k,60), grid(win,k+1,60)')
s=s.replace('XI.lo+(XI.hi-XI.lo)*a_/NG7, XI.lo+(XI.hi-XI.lo)*(a_+1)/NG7','grid(XI,a_,NG7), grid(XI,a_+1,NG7)').replace('UI.lo+(UI.hi-UI.lo)*b_/NG7, UI.lo+(UI.hi-UI.lo)*(b_+1)/NG7','grid(UI,b_,NG7), grid(UI,b_+1,NG7)')
s=s.replace("M['A8']=g8-Dmax","M['A8']=sub(I(g8),I(Dmax)).lo").replace("M['A9']=rmin-(Dmax+lmax)","M['A9']=sub(I(rmin),add(I(Dmax),I(lmax))).lo")
s=s.replace('tot+=n; nopen += 1 if bad else 0','tot+=n; nopen += 1 if bad else 0\n        rows.append({"Ha":Hl,"Hb":Hh,"T":[Tlo,Thi],"margins":M,"boxes":n,"passed":not bad})')
s=s.replace('log.close(); return nopen','log.close(); open("corner_certificate.json","w").write(json.dumps({"cells":rows,"minimum_margins":gm,"boxes":tot,"open":nopen,"seconds":time.time()-t0},indent=2)+"\\n"); return nopen')
p.write_text(s)
(root/'src/corner_replay.py').write_text('''#!/usr/bin/env python3
"""Directed corner replay; all output is inside o2cert."""
import pathlib, sys, os
ROOT=pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'src/corner_impl'))
os.chdir(ROOT)
from run_corner import main
raise SystemExit(0 if main()==0 else 1)
''')
