"""Rebind saved data after the driver-only discard/scheduling update.
Every prior byte remains in initial-pass; verify then replays all retained leaves.
"""
import pathlib,json,shutil,hashlib
import driver
r=driver.ROOT;b=r/'initial-pass';b.mkdir(exist_ok=True)
for name in ('certificate.json','gates.json','src/driver.py'):
 p=r/name
 if p.exists() and name!='src/driver.py':shutil.copy2(p,b/p.name)
for p in (r/'cells').glob('*.json'):
 q=b/'cells'/p.name;q.parent.mkdir(exist_ok=True);shutil.copy2(p,q)
 row=json.loads(p.read_text());row['source_hashes']=driver.hashes();driver.save(str(p.relative_to(r)),row)
c=json.loads((r/'certificate.json').read_text());c['source_hashes']=driver.hashes()
for row in c['cells']:row['source_hashes']=driver.hashes()
driver.save('certificate.json',c)
driver.save('initial-pass/migration.json',{'reason':'Driver-only sigma discard, H splitting and H-coverage verification; kernel unchanged','retained_leaves':sum(len(a['rectangles']) for a in c['cells']),'new_source_hashes':driver.hashes(),'old_certificate_sha256':hashlib.sha256((b/'certificate.json').read_bytes()).hexdigest()})
