from pathlib import Path
p=Path(__file__).with_name('driver.py');s=p.read_text()
s=s.replace('import os, pathlib, time, functools','import os, pathlib, time, functools, concurrent.futures')
s=s.replace("q=-Decimal(1)/Decimal('0.890900')-Decimal('0.15');f=float(q)","q=-Decimal(1)/Decimal('0.890900')-Decimal('0.15');f=float(q)")
s=s.replace("else:\n        edges=[-TOP,JE[0]", "else:\n        edges=[-TOP,JE[0]")
s=s.replace("elapsed=r['seconds']", "elapsed=r['seconds']")
s=s.replace("reason='complete';lastsave=start", "reason='complete';lastsave=start\n    discards=sum(1 for row in leaves if len(row)>5 and row[5]=='sigma')")
s=s.replace("'discards':0", "'discards':discards")
s=s.replace("min((r[4] for r in leaves),default=None)","min((r[4] for r in leaves if r[4] is not None),default=None)")
s=s.replace("_,r=heapq.heappop(heap);margin,k=rect_test(r,a,b,t,budget,tol);tested+=1;innern+=k", """_,r=heapq.heappop(heap)
        # Corollary 10.1: exact H=2 bound plus affine H dependence.
        # This certifies directly against F6, not against the trial L.
        sigma_lower=DN(DN(LOW-r[1])-r[3])
        if sigma_lower>=5:
            leaves.append([*r,None,'sigma']);tested+=1;discards+=1
            continue
        margin,k=rect_test(r,a,b,t,budget,tol);tested+=1;innern+=k""")
a=s.index('def run(args):');b=s.index('\ndef verify():',a)
s=s[:a]+'''def run(args):
    gate=json.loads((ROOT/'gates.json').read_text());assert gate['passed'] and gate['source_hashes']==hashes(),'current kernel must pass gates'
    (ROOT/'cells').mkdir(exist_ok=True);start=time.monotonic();jobs=[];records=[];attempts=[]
    old=json.loads((ROOT/'certificate.json').read_text()) if (ROOT/'certificate.json').exists() else None
    if old:
        assert old['source_hashes']==hashes()
        attempts=old.get('attempts',[])
        initial=old['cells']
    else:initial=[{'id':f'H{i}','Ha':a,'Hb':b,'proved':False} for i,(a,b) in enumerate(cells())]
    for r in initial:
        if r['proved']:records.append(r)
        else:jobs.append((r['id'],r['Ha'],r['Hb'],args.seconds,args.max_boxes,args.inner_budget,args.tol))
    def checkpoint(unstarted,pending):
        # Placeholder rows preserve exact H coverage even between completions.
        queued=[{'id':j[0],'Ha':j[1],'Hb':j[2],'proved':False,'reason':'queued'} for j in unstarted+list(pending.values())]
        save('certificate.json',{'format':1,'domain':[H0,2.],'J_odd':J,'J_even':JE,'source_hashes':hashes(),'cells':sorted(records+queued,key=lambda x:x['Ha']),'attempts':attempts,'wall_seconds':time.monotonic()-start,'complete':not queued and all(r['proved'] for r in records)})
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
        pending={}
        while jobs or pending:
            while jobs and len(pending)<args.workers:
                j=jobs.pop(0);pending[pool.submit(cell_job,j)]=j
            checkpoint(jobs,pending)
            done,_=concurrent.futures.wait(pending,timeout=1,return_when=concurrent.futures.FIRST_COMPLETED)
            for f in done:
                j=pending.pop(f);r=f.result();depth=len(r['id'])-len(r['id'].rstrip('ab'))
                log('run.log',json.dumps({k:v for k,v in r.items() if k not in ('rectangles','pending','source_hashes')}))
                if not r['proved'] and depth<args.split_depth:
                    attempts.append({k:v for k,v in r.items() if k not in ('rectangles','pending')})
                    mid=(r['Ha']+r['Hb'])/2
                    # Warm-start children from the exact parent partition.
                    partition=[v[:4] for v in r['rectangles']]+r['pending']
                    for suffix,aa,bb in [('a',r['Ha'],mid),('b',mid,r['Hb'])]:
                        ident=r['id']+suffix;row=dict(r,id=ident,Ha=aa,Hb=bb,rectangles=[],pending=partition,outer_boxes=0,inner_boxes=0,seconds=0.,proved=False)
                        save(f'cells/{ident}.json',row)
                        jobs.append((ident,aa,bb,args.seconds,args.max_boxes,args.inner_budget,args.tol))
                else:records.append(r)
                checkpoint(jobs,pending)
    checkpoint([],{});log('run.log',f'FINISH wall_seconds={time.monotonic()-start:.6f} complete={all(r["proved"] for r in records)}')
''' +s[b:]
s=s.replace("start=time.monotonic();c=json.loads((ROOT/'certificate.json').read_text());assert c['source_hashes']==hashes();count=0", """start=time.monotonic();c=json.loads((ROOT/'certificate.json').read_text());assert c['source_hashes']==hashes();count=0
    end=H0
    for row in c['cells']:
        assert row['Ha']==end and row['Hb']>end
        end=row['Hb']
    assert end==2.
""")
s=s.replace("v,_=rect_test(tuple(r[:4]),row['Ha'],row['Hb'],row['theta'],row['budget_inner'],row['tol_inner']);assert v==r[4] and v>0;count+=1", """if len(r)>5 and r[5]=='sigma':assert DN(DN(LOW-r[1])-r[3])>=5
            else:
                v,_=rect_test(tuple(r[:4]),row['Ha'],row['Hb'],row['theta'],row['budget_inner'],row['tol_inner']);assert v==r[4] and v>0
            count+=1""")
s=s.replace("p.add_argument('--tol',type=float,default=1e-5);a=p.parse_args()", "p.add_argument('--tol',type=float,default=1e-5);p.add_argument('--split-depth',type=int,default=1);a=p.parse_args()")
p.with_name('driver.next.py').write_text(s)
